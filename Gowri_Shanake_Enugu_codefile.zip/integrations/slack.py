
import os
import urllib.parse
import httpx
from fastapi import Request
from ..redis_client import add_key_value_redis, get_value_redis

SLACK_CLIENT_ID = os.environ.get("SLACK_CLIENT_ID", "")
SLACK_CLIENT_SECRET = os.environ.get("SLACK_CLIENT_SECRET", "")
SLACK_REDIRECT_URI = os.environ.get("SLACK_REDIRECT_URI", "http://localhost:8000/slack/oauth2callback")

SLACK_OAUTH_AUTHORIZE_URL = "https://slack.com/oauth/v2/authorize"
SLACK_OAUTH_ACCESS_URL = "https://slack.com/api/oauth.v2.access"
SLACK_CONVERSATIONS_LIST_URL = "https://slack.com/api/conversations.list"

# Use a namespaced key per user/org
def _token_key(user_id: str, org_id: str) -> str:
    return f"slack:token:{org_id}:{user_id}"

async def authorize_slack(user_id: str, org_id: str):
    scope = urllib.parse.quote("channels:read,groups:read,conversations:read,chat:write,users:read")
    params = {
        "client_id": SLACK_CLIENT_ID,
        "scope": "channels:read,groups:read,conversations:read,chat:write,users:read",
        "user_scope": "",
        "redirect_uri": SLACK_REDIRECT_URI,
        "state": f"{org_id}:{user_id}",
    }
    url = f"{SLACK_OAUTH_AUTHORIZE_URL}?{urllib.parse.urlencode(params)}"
    return {"auth_url": url}

async def oauth2callback_slack(request: Request):
    params = dict(request.query_params)
    code = params.get("code")
    state = params.get("state", "")
    org_id, user_id = (state.split(":", 1) + [""])[:2]

    async with httpx.AsyncClient(timeout=20.0) as client:
        token_resp = await client.post(SLACK_OAUTH_ACCESS_URL, data={
            "client_id": SLACK_CLIENT_ID,
            "client_secret": SLACK_CLIENT_SECRET,
            "code": code,
            "redirect_uri": SLACK_REDIRECT_URI
        })
        data = token_resp.json()
        ok = data.get("ok")
        if not ok:
            return {"status": "error", "error": data}

        access_token = data.get("access_token")
        # store bot token
        await add_key_value_redis(_token_key(user_id, org_id), access_token)

    return {"status": "connected"}

async def get_slack_credentials(user_id: str, org_id: str):
    token = await get_value_redis(_token_key(user_id, org_id))
    if token:
        token = token.decode() if isinstance(token, (bytes, bytearray)) else token
    return {"connected": bool(token)}

async def get_items_slack(user_id: str, org_id: str):
    token = await get_value_redis(_token_key(user_id, org_id))
    if not token:
        return {"items": []}
    token = token.decode() if isinstance(token, (bytes, bytearray)) else token

    items = []
    async with httpx.AsyncClient(timeout=20.0) as client:
        cursor = None
        while True:
            params = {"limit": 200}
            if cursor:
                params["cursor"] = cursor
            resp = await client.get(SLACK_CONVERSATIONS_LIST_URL, headers={
                "Authorization": f"Bearer {token}"
            }, params=params)
            data = resp.json()
            if not data.get("ok"):
                break
            for ch in data.get("channels", []):
                items.append({
                    "id": ch.get("id"),
                    "type": "slack_channel",
                    "directory": False,
                    "parent_path_or_name": None,
                    "parent_id": None,
                    "name": ch.get("name"),
                    "creation_time": ch.get("created"),
                    "last_modified_time": None,
                    "url": f"https://app.slack.com/client/{ch.get('context_team_id')}/{ch.get('id')}",
                    "children": [],
                    "mime_type": None,
                    "delta": None,
                    "drive_id": None,
                    "visibility": "public" if not ch.get("is_private") else "private",
                })
            cursor = data.get("response_metadata", {}).get("next_cursor")
            if not cursor:
                break

    return {"items": items}
